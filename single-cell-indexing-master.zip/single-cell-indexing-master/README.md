# Single-cell indexing

## Environment setup biocomp

- Create conda environment `conda env create -f environment.yml`
- Activate conda environment `conda activate single-cell-indexing`
- Copy credentials template and fill it out `cp credentials-copy.yml credentials.yml`
- fill out credentials.yml with the credentials for scseq MongoDB you can find here https://rochewiki.roche.com/confluence/display/BEDA/Credentials


Before creating a new index run the two commands in the files `create-term-mapping.txt` and `create-dataset-mapping.txt`. You can copy and paste thos commands in the Elastic Search Console https://kibana-pmda.kubemea.science.roche.com/app/dev_tools#/console

## Run script on biocomp
`./start-query.sh`
