import json
import requests
import urllib3
import multiprocessing
import time
import re
import yaml
import sys
from multiprocessing import Process
from collections import ChainMap
from pymongo import MongoClient
from bson import ObjectId
from typing import Dict, List
from loguru import logger

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
with open("./credentials.yml") as c:
    configuration = yaml.safe_load(c)

    HOST = configuration["hostname"]
    PORT = int(configuration["port"])
    DBNAME = configuration["dbname"]
    USERNAME = configuration["username"]
    PASSWORD = configuration["password"]
    ELASTICSEARCH_USERNAME = configuration["elasticsearch_username"]
    ELASTICSEARCH_PASSWORD = configuration["elasticsearch_password"]
    ELASTICSEARCH_URL = configuration["elasticsearch_url"]
    INDEXNAME = configuration["datasetindex"]
    AUTOCOMPLETEINDEX = configuration["autocompleteindex"]

headers = {
    "Content-Type": "application/json",
    "charset": "UTF-8",
    "User-Agent": "Mozilla/5.0",
}
TERMS_INTERATION_SIZE = 5000
TERM_COMBINATION_LENGTH = 3
session = requests.Session()

escapeRules = {
    "+": r"\+",
    "-": r"\-",
    "&": r"\&",
    "|": r"\|",
    "!": r"\!",
    "(": r"\(",
    ")": r"\)",
    "{": r"\{",
    "}": r"\}",
    "[": r"\[",
    "]": r"\]",
    "^": r"\^",
    "~": r"\~",
    "*": r"\*",
    "?": r"\?",
    ":": r"\:",
    '"': r"\"",
    "\\": r"\\;",
    "/": r"\/",
    ">": r" ",
    "<": r" ",
}


class JSONEncoder(json.JSONEncoder):
    """
    Custom JSON encoder with objectId to string conversion
    """

    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return json.JSONEncoder.default(self, o)


def escapeTerm(term):
    escapedTerm = ""
    for char in term:
        if char in escapeRules.keys():
            escapedTerm += escapeRules[char]
        else:
            escapedTerm += char

    return escapedTerm


def split_list(alist, wanted_parts: int):
    length = len(alist)
    return [
        alist[i * length // wanted_parts : (i + 1) * length // wanted_parts]
        for i in range(wanted_parts)
    ]


def get_genesymbols(ensembl_ids):
    parts = split_list(ensembl_ids, 8)
    gene_symbols = []

    for part in parts:
        res = requests.post(
            "https://gti-api.kubemea.science.roche.com/api/ensembl/gene",
            json=part,
            verify=False,
        )

        json_res = res.json()
        gene_symbols.extend(list(map(lambda g: g["Symbol"], json_res)))
        synonym_lists = map(
            lambda g: g["Synonyms"] if "Synonyms" in g else [], json_res
        )
        gene_symbols.extend(
            [synonym for synonym_list in synonym_lists for synonym in synonym_list]
        )
    return list(set(gene_symbols))


def get_cell_metadata_properties(db: MongoClient, study_id: str) -> List[Dict]:
    cell_metadata = []
    cell_metadata.append({"Condition": "$Condition"})

    pipe = []
    pipe.append({"$match": {"studyID": study_id}})
    pipe.append({"$limit": 1})
    attributes_obj = list(db["Cells"].aggregate(pipe))[0].get("attributes", dict({}))
    attributes = list(attributes_obj.keys())

    for attribute in attributes:
        if "." in attribute or not attribute:
            continue
        cell_metadata.append({f"attributes_{attribute}": f"$attributes.{attribute}"})
    return cell_metadata


def get_studydata(studyID, study_metadata_properties: List[Dict], db: MongoClient):
    """
    get study data and metadata by studyID
    """

    grouping_rules = {"_id": None}
    for cell_metadata_property in study_metadata_properties:
        grouping_rules[list(cell_metadata_property.keys())[0]] = {
            "$addToSet": f"${list(cell_metadata_property.keys())[0]}"
        }

    final_projections = dict(
        ChainMap(
            *map(
                lambda c: {list(c.keys())[0]: f"$cells.{list(c.keys())[0]}"},
                study_metadata_properties,
            )
        )
    )

    aggregations = []
    aggregations.append({"$match": {"studyID": studyID}})

    # get sample names of the study
    aggregations.append(
        {
            "$lookup": {
                "from": "Cells",
                "as": "cells",
                "let": {"studyID": "$studyID"},
                "pipeline": [
                    {"$match": {"$expr": {"$eq": ["$studyID", "$$studyID"]}}},
                    {
                        "$project": {
                            **{"_id": 0},
                            **dict(ChainMap(*study_metadata_properties)),
                        }
                    },
                    {"$group": grouping_rules},
                ],
            }
        }
    )

    # get geneIds of a study
    aggregations.append(
        {
            "$lookup": {
                "from": "LabelingSignals",
                "as": "signals",
                "let": {"studyID": "$studyID"},
                "pipeline": [
                    {"$match": {"$expr": {"$eq": ["$studyID", "$$studyID"]}}},
                    {"$project": {"_id": 0, "geneID": 1}},
                    {"$group": {"_id": None, "uniqueValues": {"$addToSet": "$geneID"}}},
                ],
            }
        }
    )
    # get unique labeling names
    aggregations.append(
        {
            "$lookup": {
                "from": "Labelings",
                "as": "labelings",
                "let": {"studyID": "$studyID"},
                "pipeline": [
                    {"$match": {"$expr": {"$eq": ["$studyID", "$$studyID"]}}},
                    {"$project": {"_id": 0, "labels": 1}},
                    {"$unwind": "$labels"},
                    {
                        "$group": {
                            "_id": None,
                            "uniqueValues": {"$addToSet": "$labels.label"},
                        }
                    },
                ],
            }
        }
    )
    aggregations.append(
        {"$unwind": {"preserveNullAndEmptyArrays": True, "path": "$labelings"}}
    )
    aggregations.append(
        {"$unwind": {"preserveNullAndEmptyArrays": True, "path": "$signals"}}
    )
    aggregations.append(
        {"$unwind": {"preserveNullAndEmptyArrays": True, "path": "$cells"}}
    )
    aggregations.append(
        {
            "$project": {
                **{
                    "_id": 0,
                    "studyId": "$studyID",
                    "pstorePath": "$pstore_path",
                    "studyDescription": "$study_description",
                    "studyDisease": "$study_disease",
                    "studyTissue": "$study_tissue",
                    "reference": "$reference",
                    "species": 1,
                    "user": 1,
                    "date": "$Date",
                    "isReference": 1,
                    "status": 1,
                    "platform": 1,
                    "nsignals": 1,
                    "ncells": 1,
                    "genomeDraft": "$genome_draft",
                    "gtfPath": "$gtf_path",
                    "valid": 1,
                    "isPublic": 1,
                    "genes": "$signals.uniqueValues",
                    "labelings": "$labelings.uniqueValues",
                },
                **final_projections,
            }
        }
    )
    # print(aggregations)
    study = list(db.Studies.aggregate(aggregations, allowDiskUse=True))[0]

    if "genes" in study and study["genes"]:
        study["geneSymbols"] = get_genesymbols(study["genes"])
    return study


def get_existing_term(term):
    # logger.info(f"Get existing term {term}")
    request_body = {
        "query": {
            "query_string": {"default_field": "term.keyword", "query": escapeTerm(term)}
        }
    }
    with session.post(
        "{}/{}/_search".format(ELASTICSEARCH_URL, AUTOCOMPLETEINDEX),
        json=request_body,
        headers=headers,
        stream=False,
        auth=(ELASTICSEARCH_USERNAME, ELASTICSEARCH_PASSWORD),
        verify=False,
    ) as res:
        res.content
        term_data = res.json()
    if "hits" in term_data and "hits" in term_data["hits"]:
        if len(term_data["hits"]["hits"]) > 0:
            return term_data["hits"]["hits"][0]
        else:
            return None
    else:
        logger.debug("hits does not exists in response")
        # print(json.dumps(term_data))


def add_term(term, studyId):
    existing_term = get_existing_term(term)
    res = None
    if existing_term is not None:
        if studyId not in existing_term["_source"]["studyIds"]:
            update_body = {
                "script": {
                    "source": "ctx._source.studyIds.add(params.studyId)",
                    "lang": "painless",
                    "params": {"studyId": studyId},
                }
            }
            with session.post(
                "{}/{}/_update/{}".format(
                    ELASTICSEARCH_URL, AUTOCOMPLETEINDEX, existing_term["_id"]
                ),
                json=update_body,
                headers=headers,
                stream=False,
                auth=(ELASTICSEARCH_USERNAME, ELASTICSEARCH_PASSWORD),
                verify=False,
            ) as res:
                res.content
    else:
        with session.post(
            "{}/{}/_doc".format(ELASTICSEARCH_URL, AUTOCOMPLETEINDEX),
            json={"term": term, "studyIds": [studyId]},
            headers=headers,
            stream=False,
            auth=(ELASTICSEARCH_USERNAME, ELASTICSEARCH_PASSWORD),
            verify=False,
        ) as res:
            res.content


def add_single_terms(study, studyId, cell_metadata_properties: List[Dict]):
    terms = []
    all_processes = []

    # Collect all terms
    for cell_metadata_property in cell_metadata_properties:
        terms.extend(study[list(cell_metadata_property.keys())[0]])

    terms.append(study["platform"])
    if "labelings" in study and study["labelings"]:
        terms.extend(study["labelings"])
    terms.append(study["studyDescription"])
    terms.append(study["genomeDraft"])
    if "genes" in study and study["genes"]:
        terms.extend(study["genes"])
    if "geneSymbols" in study and study["geneSymbols"]:
        terms.extend(study["geneSymbols"])
    if "cells" in study and study["cells"]:
        terms.extend(study["cells"])
    terms.append(study["species"])
    terms.append(study["studyId"])
    terms.append(study["user"])
    terms.append(study["status"])
    if "reference" in study and study["reference"]:
        terms.append(study["reference"])
    if "studyDisease" in study and study["studyDisease"]:
        terms.append(study["studyDisease"])
    if "studyTissue" in study and study["studyTissue"]:
        terms.append(study["studyTissue"])

    preprocessed_terms = []
    split_str = ",|\-|\s|\."
    logger.info(f"{len(terms)} terms to process")
    for term in terms:
        term = re.sub(r"\s+", " ", term)
        splitted_terms = re.split(split_str, term)
        preprocessed_terms.extend(splitted_terms)

        for y in range(2, TERM_COMBINATION_LENGTH + 1):
            for i in range(0, len(splitted_terms) - y + 1):
                preprocessed_terms.append(" ".join(splitted_terms[i : i + y]))

    # index each term only once
    preprocessed_terms = list(set(preprocessed_terms))

    # upload terms to elasticsearch
    for count, term in enumerate(preprocessed_terms):
        p = Process(
            target=add_term,
            args=(
                term,
                studyId,
            ),
        )

        all_processes.append(p)

    while True:
        end = min(TERMS_INTERATION_SIZE, len(all_processes))

        for process in all_processes[0:end]:
            process.start()

        for process in all_processes[0:end]:
            process.join()

        del all_processes[0:end]

        if len(all_processes) == 0:
            break


def check_study_exists(study_id: str, index_name: str = INDEXNAME):

    query_body: str = """{{
      "query" : {{
        "query_string" : {{
          "query" : "{}",
          "fields"  : ["studyId"]
        }}
      }}
    }}""".format(
        study_id
    )

    try:
        response = requests.get(
            "{}/{}/_search/".format(ELASTICSEARCH_URL, index_name),
            data=query_body,
            headers=headers,
            stream=False,
            auth=(ELASTICSEARCH_USERNAME, ELASTICSEARCH_PASSWORD),
            verify=False,
        )
    except:
        logger.error(f"Could not connect to {ELASTICSEARCH_URL}")
        return False

    if response.status_code == 200:
        response_decoded = json.loads(response.content)
        if response_decoded.get("hits").get("total").get("value") >= 1:
            return False
        else:
            return True
    else:
        logger.debug(f"Index {index_name} does not exist yet")
        return False


@logger.catch
def main():

    # Set up a connection to the mongo database
    uri = f"mongodb://{USERNAME}:{PASSWORD}@{HOST}:{PORT}/{DBNAME}"
    connection = MongoClient(uri)
    db: MongoClient = connection[DBNAME]

    try:
        # Load all studies that should be indexed
        studies = list(db.Studies.find())
    except:
        logger.error("Search in MongoDB {DBNAME} for studies failed ")
        studies = []

    # Print informations
    logger.info(f"Number of Studies to index: {len(studies)}")
    logger.info(f"Number of CPUs: {multiprocessing.cpu_count()}")

    for index, study in enumerate(studies):

        logger.info(f"Processing {study['studyID']}")

        # hack to skip these studies due to exceeding of the 16 MB limit
        if study["studyID"] in [
            "Fetal_Adrenal",
            "Fetal_Cerebellum",
            "Fetal_Cerebrum",
            "Tran2021_amygdala",
        ]:
            logger.info(f"Skipping {study['studyID']} due to 16 MB limit in MongoDB")
            continue

        if check_study_exists(study_id=study["studyID"]):
            start = time.time()
            cell_metadata_properties = get_cell_metadata_properties(
                db, study["studyID"]
            )

            # Load study data and metadata
            studydata = get_studydata(study["studyID"], cell_metadata_properties, db)
            # json_studydata = JSONEncoder().encode(studydata)
            # logger.info(f"Loaded study data for {study['studyID']}")
            # logger.info(
            #     f"Finished loading study data and meta data and took: {time.time() - start}"
            # )

            # Index the loaded data in elasticsearch
            # start = time.time()
            # response = requests.put(
            #     "{}/{}/_doc/{}".format(ELASTICSEARCH_URL, INDEXNAME, str(study["_id"])),
            #     data=json_studydata,
            #     headers=headers,
            #     stream=False,
            #     auth=(ELASTICSEARCH_USERNAME, ELASTICSEARCH_PASSWORD),
            #     verify=False,
            # )
            # logger.info(f" Finished elastic put request: {time.time() - start}")

            # if response.status_code == 201:
            #     logger.info(f"Sucessfully created study {study['studyID']}")
            # else:
            #     # Can fail with a "Limit of total fields [1000] in index [] has been exceeded"
            #     # FIX on the ES console:
            #     # PUT single-cell-datasets-v4/_settings
            #     # {
            #     # "index.mapping.total_fields.limit": 5000
            #     # }
            #     logger.error(
            #         f"Response code:{response.status_code}. Got an error on the Elastic Search put request with study {study['studyID']}"
            #     )
            #     logger.error(json.loads(response.content))

            logger.info(f"Starting to add terms: ")
            add_single_terms(studydata, str(study["_id"]), cell_metadata_properties)
            logger.info(
                f"--- study {study['studyID']} took {time.time() - start} seconds to index ---"
            )
        else:
            logger.info(f"Skipping... {study['studyID']} is already indexed")

        logger.info(
            f"#### Progress: {index + 1}/{len(studies)} #################################"
        )


if __name__ == "__main__":
    main()
