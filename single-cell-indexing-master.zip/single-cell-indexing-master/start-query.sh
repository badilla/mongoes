#!/bin/sh
#source activate single-cell-indexing
#conda activate /homebasel/biocomp/bim/.conda/envs/single-cell-indexing
python -u query-data.py
